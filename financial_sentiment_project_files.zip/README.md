
# Financial Sentiment Analysis using FinBERT

This project compares traditional rule-based sentiment analysis using VADER with transformer-based sentiment analysis using FinBERT on financial news text.

## Dataset

The project uses the Financial PhraseBank dataset, specifically the `Sentences_AllAgree` subset.

This subset contains financial news sentences where all annotators agreed on the sentiment label.

Dataset size: 2264 sentences

## Models Used

### VADER

VADER is a rule-based sentiment analysis model. It uses a dictionary of positive and negative words to calculate sentiment.

### FinBERT

FinBERT is a transformer model based on BERT and trained on financial text. It understands financial context better than simple word-based methods.

## Results

| Model | Accuracy |
|---|---:|
| VADER | 0.5782 |
| FinBERT | 0.9717 |

FinBERT performed much better than VADER on financial sentiment classification.

## Sentiment vs Stock Return

The project also demonstrates how sentiment scores can be compared with next-day Nifty 50 returns.

Pearson correlation: 0.0414

P-value: 0.2607

The correlation result is only a demonstration because the Financial PhraseBank dataset does not include dates.

## Key Learning

FinBERT is better than VADER for financial text because it understands context.

Example:

"The company avoided losses."

VADER may treat this as negative because of the word "losses", but FinBERT can understand that "avoided losses" is actually positive.

## Limitations

The dataset contains labelled financial sentences but does not contain dates.

In a production system, dated financial news headlines should be collected from a news API and matched with stock price data.

## Files

- `financial_sentiment_analysis.ipynb` - main notebook
- `financial_sentiment_results.csv` - model predictions and scores
- `model_comparison.png` - confusion matrix comparison
- `financial_sentiment_insights.png` - final visual dashboard
